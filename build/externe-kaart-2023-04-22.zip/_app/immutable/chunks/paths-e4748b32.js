const a="/embed-kaart";let e=a;function t(s){e=s}export{e as a,a as b,t as s};
