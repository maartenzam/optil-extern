import{default as t}from"../components/error.svelte-f761ce39.js";export{t as component};
