import{_ as r}from"./_layout-da46b06b.js";import{default as t}from"../components/layout.svelte-a102fb50.js";export{t as component,r as universal};
