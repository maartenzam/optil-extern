import{p}from"../../chunks/_layout-da46b06b.js";export{p as prerender};
